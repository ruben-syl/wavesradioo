const audioPlayer = document.querySelector('audio');
const playButton = document.getElementById('play-button');

playButton.addEventListener('click', () => {
    if (audioPlayer.paused) {
        audioPlayer.play();
    } else {
        audioPlayer.pause();
    }
});
